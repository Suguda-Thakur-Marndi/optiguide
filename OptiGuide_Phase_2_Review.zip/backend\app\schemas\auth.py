import uuid
from datetime import datetime
from enum import Enum

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator


class UserRole(str, Enum):
    """Allowed user roles in OptiGuide platform."""

    PATIENT = "patient"
    OPTOMETRIST = "optometrist"
    SHOPKEEPER = "shopkeeper"
    ADMIN = "admin"


class UserRegisterRequest(BaseModel):
    """Payload for user registration."""

    email: EmailStr = Field(..., json_schema_extra={"example": "patient@example.com"})
    password: str = Field(..., min_length=8, json_schema_extra={"example": "SecurePass123!"})
    full_name: str = Field(
        ..., min_length=2, max_length=255, json_schema_extra={"example": "Jane Doe"}
    )
    role: UserRole = Field(default=UserRole.PATIENT, json_schema_extra={"example": "patient"})
    phone_number: str | None = Field(
        default=None, max_length=50, json_schema_extra={"example": "+15551234567"}
    )
    preferred_language: str = Field(
        default="en", max_length=10, json_schema_extra={"example": "en"}
    )

    @field_validator("email")
    @classmethod
    def normalize_email(cls, v: str) -> str:
        return v.lower().strip()

    model_config = ConfigDict(populate_by_name=True)


class UserLoginRequest(BaseModel):
    """Payload for user authentication."""

    email: EmailStr = Field(..., json_schema_extra={"example": "patient@example.com"})
    password: str = Field(..., json_schema_extra={"example": "SecurePass123!"})

    @field_validator("email")
    @classmethod
    def normalize_email(cls, v: str) -> str:
        return v.lower().strip()


class TokenRefreshRequest(BaseModel):
    """Payload for refresh token exchange or logout."""

    refresh_token: str = Field(..., json_schema_extra={"example": "raw_refresh_token_string"})


class UserProfileResponse(BaseModel):
    """Public representation of an OptiGuide user profile."""

    id: uuid.UUID
    email: str
    full_name: str
    role: str
    phone_number: str | None = None
    preferred_language: str = "en"
    is_active: bool
    is_verified: bool
    created_at: datetime
    updated_at: datetime
    last_login_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)


class AuthResponse(BaseModel):
    """OAuth2 / JWT response returned upon successful authentication or registration."""

    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_in: int
    user: UserProfileResponse


class TokenRefreshResponse(BaseModel):
    """Response returned upon successful token rotation."""

    access_token: str
    refresh_token: str
    token_type: str = "Bearer"
    expires_in: int


class UserUpdateRequest(BaseModel):
    """Payload for updating user profile fields."""

    full_name: str | None = Field(default=None, min_length=2, max_length=255)
    phone_number: str | None = Field(default=None, max_length=50)
    preferred_language: str | None = Field(default=None, max_length=10)


class UserStatusUpdateRequest(BaseModel):
    """Admin-only payload for updating account status or role."""

    is_active: bool | None = None
    is_verified: bool | None = None
    role: UserRole | None = None


class SessionResponse(BaseModel):
    """Diagnostic response representing an active or revoked refresh token session."""

    id: uuid.UUID
    user_agent: str | None = None
    ip_address: str | None = None
    is_revoked: bool
    expires_at: datetime
    created_at: datetime
    revoked_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True)


class MessageResponse(BaseModel):
    """Generic status and message response."""

    message: str
    success: bool = True
