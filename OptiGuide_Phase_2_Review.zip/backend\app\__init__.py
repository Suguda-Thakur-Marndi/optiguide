"""OptiGuide FastAPI Application Package."""
