import uuid
from datetime import UTC, datetime

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.models.session import UserSession


class SessionRepository:
    """Data access repository for UserSession entities."""

    @staticmethod
    def create(db: Session, session: UserSession) -> UserSession:
        db.add(session)
        db.commit()
        db.refresh(session)
        return session

    @staticmethod
    def get_by_token_hash(db: Session, token_hash: str) -> UserSession | None:
        stmt = select(UserSession).where(UserSession.session_token_hash == token_hash)
        return db.execute(stmt).scalar_one_or_none()

    @staticmethod
    def get_sessions_for_user(db: Session, user_id: uuid.UUID) -> list[UserSession]:
        stmt = (
            select(UserSession)
            .where(UserSession.user_id == user_id)
            .order_by(UserSession.created_at.desc())
        )
        return list(db.execute(stmt).scalars().all())

    @staticmethod
    def revoke_session(db: Session, session: UserSession) -> None:
        session.is_revoked = True
        session.revoked_at = datetime.now(UTC)
        db.commit()
        db.refresh(session)

    @staticmethod
    def revoke_all_for_user(db: Session, user_id: uuid.UUID) -> int:
        now = datetime.now(UTC)
        stmt = (
            update(UserSession)
            .where(
                UserSession.user_id == user_id,
                UserSession.is_revoked.is_(False),
            )
            .values(is_revoked=True, revoked_at=now)
        )
        result = db.execute(stmt)
        db.commit()
        return result.rowcount
