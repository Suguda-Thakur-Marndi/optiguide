import time
import uuid
from collections import defaultdict
from collections.abc import Callable, Generator
from typing import Annotated

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.exceptions import (
    AuthenticationException,
    ForbiddenException,
    RateLimitExceededException,
    TokenInvalidException,
    UserInactiveException,
)
from app.core.security import decode_access_token
from app.database.session import get_db
from app.models.user import User
from app.repositories.user_repo import UserRepository

# Optional bearer scheme so missing tokens raise custom AuthenticationException
security_bearer = HTTPBearer(auto_error=False)


def get_database() -> Generator[Session, None, None]:
    """Dependency yielding a thread-local SQLAlchemy session."""
    yield from get_db()


def get_client_ip(request: Request) -> str:
    """Extracts client IP coordinate from headers or connection state."""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "127.0.0.1"


# In-memory sliding-window request tracker for rate limiting
_rate_limit_records: dict[str, list[float]] = defaultdict(list)


def rate_limit(max_requests: int, window_seconds: int = 60) -> Callable:
    """In-memory rate limiter dependency based on client IP coordinate."""

    async def _rate_limiter(request: Request) -> None:
        client_ip = get_client_ip(request)
        endpoint = request.url.path
        key = f"{client_ip}:{endpoint}"
        now = time.time()

        # Clean expired timestamps outside sliding window
        window_start = now - window_seconds
        records = [ts for ts in _rate_limit_records[key] if ts > window_start]
        records.append(now)
        _rate_limit_records[key] = records

        if len(records) > max_requests:
            raise RateLimitExceededException("Too many requests. Please try again later.")

    return _rate_limiter


def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(security_bearer)],
    db: Annotated[Session, Depends(get_db)],
) -> User:
    """Extracts, verifies, and resolves the authenticated User from Bearer token."""
    if credentials is None or not credentials.credentials:
        raise AuthenticationException("Authentication credentials were not provided.")

    token = credentials.credentials
    payload = decode_access_token(token)

    sub = payload.get("sub")
    if not sub:
        raise TokenInvalidException("Token subject identifier missing.")

    try:
        user_uuid = uuid.UUID(sub)
    except ValueError as err:
        raise TokenInvalidException("Invalid user identifier in token.") from err

    user = UserRepository.get_by_id(db, user_uuid)
    if user is None:
        raise AuthenticationException("User account not found.")

    if not user.is_active:
        raise UserInactiveException("User account has been deactivated.")

    return user


def get_current_active_user(
    current_user: Annotated[User, Depends(get_current_user)],
) -> User:
    """Ensures authenticated user is active."""
    if not current_user.is_active:
        raise UserInactiveException("User account has been deactivated.")
    return current_user


def require_roles(*allowed_roles: str) -> Callable:
    """Factory creating an RBAC dependency enforcing specified role membership."""

    def _role_checker(
        current_user: Annotated[User, Depends(get_current_active_user)],
    ) -> User:
        if current_user.role not in allowed_roles:
            raise ForbiddenException(
                f"Operation requires one of the following roles: {', '.join(allowed_roles)}."
            )
        return current_user

    return _role_checker


# Pre-configured role dependencies
require_admin = require_roles("admin")
require_clinician = require_roles("optometrist", "admin")
